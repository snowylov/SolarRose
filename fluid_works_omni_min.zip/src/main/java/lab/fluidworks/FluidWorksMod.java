package lab.fluidworks;
import net.fabricmc.api.ModInitializer;
public class FluidWorksMod implements ModInitializer {
  public static final String MODID="fluid_works";
  @Override public void onInitialize(){
    lab.fluidworks.omni.OmniCommand.init(
      new lab.fluidworks.omni.Jaller(lab.fluidworks.omni.OmniLanguage.SIMPLE)
        .add(new lab.fluidworks.agents.NuparuAgent())
        .add(new lab.fluidworks.agents.KonguAgent())
    );
  }
}
