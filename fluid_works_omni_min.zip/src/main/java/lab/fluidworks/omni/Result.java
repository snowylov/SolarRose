package lab.fluidworks.omni; public record Result(String agent,String title,String body){ public static Result of(String a,String b){ return new Result(a,a,b);} }
