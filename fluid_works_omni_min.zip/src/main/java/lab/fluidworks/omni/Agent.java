package lab.fluidworks.omni; public interface Agent{ String name(); boolean supports(Task t); Result run(Task t);}
