package lab.fluidworks; import net.fabricmc.api.ClientModInitializer; public class FluidWorksClient implements ClientModInitializer { public void onInitializeClient(){} }
