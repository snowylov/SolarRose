from .component import BuilderGPTComponent

def get_component():
    return BuilderGPTComponent()
