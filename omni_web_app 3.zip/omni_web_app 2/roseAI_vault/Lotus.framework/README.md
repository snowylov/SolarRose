# Lotus.framework

This is the main Lotus Framework build system. All text-based outputs have been generated uniquely in the /docs folder.

To view extracted documentation, visit the /docs directory.
