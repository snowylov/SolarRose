# Lotus.framework

### Components:
- 📂 schema/ — Unified schema files (AI memory, VM + LEGO builder)
- 📂 scripts/ — AI-based Python utilities
- 📂 requests/ — Mixed reality, AR tracking, LEGO and texture jobs
- 📂 config/ — Core Lotus configuration
- 📜 README.md — This document
- 🤖 auto_readme_injector.py — Injects README on tool-ready detection

### Tools:
- Self-adaptive schema
- Parallel query execution
- Blockchain-integrity validation
- LEGO model export to .io, .stl, .csv, .json
