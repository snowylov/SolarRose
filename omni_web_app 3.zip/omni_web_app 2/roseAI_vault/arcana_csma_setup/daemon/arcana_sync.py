import time, os, subprocess
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

WATCH_PATHS = ['../mods', '../saves/ArcanaWorld/datapacks']

class SyncHandler(FileSystemEventHandler):
    def on_modified(self, event):
        if event.src_path.endswith('.java'):
            print(f"🔧 Recompiling Java file: {event.src_path}")
            subprocess.run(['javac', event.src_path])
        elif event.src_path.endswith('.json') or event.src_path.endswith('.mcmeta'):
            print(f"♻️ Reload triggered: {event.src_path}")
        else:
            print(f"📁 File change detected: {event.src_path}")

observer = Observer()
for path in WATCH_PATHS:
    if os.path.exists(path):
        observer.schedule(SyncHandler(), path=path, recursive=True)

observer.start()
print("🧪 ArcanaCSMA Python Daemon Running (CTRL+C to stop)")
try:
    while True:
        time.sleep(2)
except KeyboardInterrupt:
    observer.stop()
observer.join()
