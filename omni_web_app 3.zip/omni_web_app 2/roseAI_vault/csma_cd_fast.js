class Channel {
  isFree() {
    return Math.random() > 0.05; // 95% chance it's free
  }

  detectCollision() {
    return Math.random() < 0.1; // 10% collision rate
  }

  waitBackoff() {
    const backoff = Math.floor(Math.random() * 50); // faster backoff
    return new Promise(resolve => setTimeout(resolve, backoff));
  }

  async sendData() {
    return !this.detectCollision(); // Returns true if no collision
  }
}

async function csmaCD(channel, dataQueue) {
  while (dataQueue.length > 0) {
    const data = dataQueue.shift();
    let sent = false;
    while (!sent) {
      if (!channel.isFree()) {
        await new Promise(resolve => setTimeout(resolve, 20));
        continue;
      }
      sent = await channel.sendData();
      if (!sent) {
        await channel.waitBackoff();
      }
    }
  }
}

// Run
(async () => {
  const channel = new Channel();
  const dataQueue = ["Fast", "Reliable", "CSMA", "CD"];
  await csmaCD(channel, dataQueue);
})();
