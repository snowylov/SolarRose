package lab.fluidworks.omni;
public final class Jaller{
  private final java.util.List<Agent> agents=new java.util.ArrayList<>(); private final OmniLanguage lang;
  public Jaller(OmniLanguage l){ this.lang=l==null?OmniLanguage.SIMPLE:l; }
  public Jaller add(Agent a){ agents.add(a); return this; }
  public Result handle(Task t){
    return agents.stream().map(a->new Object[]{a,score(a,t)}).sorted((x,y)->Double.compare((double)y[1],(double)x[1]))
      .map(x->((Agent)x[0]).run(t)).findFirst().orElse(Result.of("none","No agent accepted."));
  }
  private double score(Agent a, Task t){ double s=a.supports(t)?0.6:0.0; if(a.name().equalsIgnoreCase("kongu")) s+= lang.score(t,"animal","bird","wildlife","bug","insect")*0.4; return s; }
}
