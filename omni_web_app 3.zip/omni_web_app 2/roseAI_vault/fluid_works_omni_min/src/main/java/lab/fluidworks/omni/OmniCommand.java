package lab.fluidworks.omni;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import static net.minecraft.server.command.CommandManager.literal;
import static net.minecraft.server.command.CommandManager.argument;
public final class OmniCommand{
  private static Jaller J;
  public static void init(Jaller j){ J=j; CommandRegistrationCallback.EVENT.register((d,ra,env)->reg(d)); }
  private static void reg(CommandDispatcher<ServerCommandSource> d){
    d.register(literal("omni").then(literal("run").then(argument("q", StringArgumentType.greedyString()).executes(c->{
      var r=J.handle(new Task(c.getSource().getName(), StringArgumentType.getString(c,"q"), "US", new String[0], java.util.Map.of()));
      c.getSource().sendFeedback(()-> Text.literal("["+r.agent()+"] "+r.body()), false); return 1;
    }))));
  }
}
