# stream_handler.py
class StreamHandler:
    def call_ai(self, prompt):
        # Replace this with real API call with streaming
        print(f"🔍 Calling AI with prompt of {len(prompt)} characters...")
        return f"Simulated response for: {prompt[:50]}..."
