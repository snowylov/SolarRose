# chunker.py
import tiktoken
ENCODER = tiktoken.get_encoding("gpt2")

def chunk_text(text, max_tokens):
    tokens = ENCODER.encode(text)
    chunks = []
    start = 0
    while start < len(tokens):
        end = start + max_tokens
        chunk_tokens = tokens[start:end]
        chunks.append(ENCODER.decode(chunk_tokens))
        start = end
    return chunks
