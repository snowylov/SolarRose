# workflow_engine.py
class WorkflowEngine:
    def __init__(self, chunker, batcher, cache, stream_handler):
        self.chunker = chunker
        self.batcher = batcher
        self.cache = cache
        self.stream_handler = stream_handler

    def process(self, large_texts):
        all_responses = []
        for text in large_texts:
            chunks = self.chunker.chunk_text(text, max_tokens=1000)
            for chunk in chunks:
                cached = self.cache.get(chunk)
                if cached:
                    all_responses.append(cached)
                    continue
                batch_prompt = self.batcher.create_batch_prompt([chunk])
                response = self.stream_handler.call_ai(batch_prompt)
                self.cache.set(chunk, response)
                all_responses.append(response)
        return all_responses
