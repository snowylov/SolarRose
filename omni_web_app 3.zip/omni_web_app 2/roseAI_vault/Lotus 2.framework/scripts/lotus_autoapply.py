# lotus_autoapply.py
from scripts.workflow_engine import WorkflowEngine
from scripts.batch_processor import BatchProcessor
from scripts.chunker import chunk_text
from scripts.cache_manager import CacheManager
from scripts.stream_handler import StreamHandler

def init():
    print("🔁 Lotus Batch Processor loaded.")
    cache = CacheManager()
    batcher = BatchProcessor(cache)
    chunker = type('Chunker', (), {"chunk_text": staticmethod(chunk_text)})
    engine = WorkflowEngine(chunker, batcher, cache, StreamHandler())
    return engine
