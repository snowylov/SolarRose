
-- enhance_clone.lua
-- Allows applying clone upgrades using redstone blocks

local enhancement_cost = 1 -- blocks of redstone

function hasRedstoneBlock(player)
    return player:getInventory():hasItem("minecraft:redstone_block", enhancement_cost)
end

function consumeRedstoneBlock(player)
    player:getInventory():removeItem("minecraft:redstone_block", enhancement_cost)
end

function applyEnhancement(clone, player, enhancement)
    if not hasRedstoneBlock(player) then
        print("You need at least 1 Redstone Block.")
        return false
    end

    consumeRedstoneBlock(player)

    if enhancement == "no_hunger" then
        clone:setHungerLoss(false)
    elseif enhancement == "effect_immunity" then
        clone:setEffectImmunity(true)
    elseif enhancement == "poison_touch" then
        clone:onHit(function(target)
            target:addEffect("minecraft:poison", 10, 1)
        end)
    elseif enhancement == "death_touch" then
        clone:onHit(function(target)
            if not target:isBoss() then
                target:setHealth(0)
            end
        end)
    elseif enhancement == "health_40" then
        clone:setMaxHealth(40)
        clone:setHealth(40)
    elseif enhancement == "max_air_60" then
        clone:setMaxAir(1200) -- 60 seconds underwater
    elseif enhancement == "max_armor_20" then
        clone:setArmor(20)
    end

    print("Enhancement '" .. enhancement .. "' applied.")
    return true
end

-- Example GUI command hook:
function onCloneEnhanceMenu(player, clone)
    -- You'd use GUI buttons mapped to:
    -- /enhance_clone <enhancement>
end
