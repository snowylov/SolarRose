
import os
import subprocess
import tkinter as tk
from tkinter import messagebox

def launch_minecraft():
    try:
        subprocess.run(['java', '-Xmx2G', '-jar', './build/libs/ArcanaScript_Mod_v1.0.jar'])
    except Exception as e:
        messagebox.showerror("Error", str(e))

root = tk.Tk()
root.title("ArcanaScript Mod Launcher")

frame = tk.Frame(root, padx=20, pady=20)
frame.pack()

tk.Label(frame, text="ArcanaScript Launcher", font=("Arial", 16)).pack(pady=10)
tk.Button(frame, text="🚀 Launch Mod", command=launch_minecraft).pack(pady=5)
tk.Button(frame, text="📂 Open Project Folder", command=lambda: os.startfile(".")).pack(pady=5)
tk.Button(frame, text="🛑 Exit", command=root.quit).pack(pady=10)

root.mainloop()
