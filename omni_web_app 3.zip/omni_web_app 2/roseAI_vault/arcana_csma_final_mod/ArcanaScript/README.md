
# ArcanaScript Mod (with BuilderGPT, Lua, Python, and Auto-Reload)

## 🛠 Features
- Lua and Python scripting support (via LuaJ and Jython)
- Hot-reloading on file change
- `/script reload` command support
- BuilderGPT structure generation stub
- Supports Fabric Loader (1.21.5 targeted)

## 🚀 Quick Start

1. Make sure you have Java 17+ and Gradle installed:
   ```bash
   sdk install gradle
   ```

2. Navigate to the project folder:
   ```bash
   cd ArcanaScript_GradleProject
   ```

3. Run the wrapper and build:
   ```bash
   gradle wrapper
   ./gradlew build
   ```

4. Drop the built `.jar` from `build/libs/` into your Minecraft `/mods` folder.

## 📂 Folder Structure

- `scripts/` – Place your `.lua` and `.py` scripts here.
- `addons/` – Future support for JSON-based structure and mod extensions.
- `gradle/` – Gradle wrapper files.

## 🧙 Example Scripts
```lua
-- scripts/example_tower.lua
print("LuaJ says: Tower spawned!")
```

```python
# scripts/example_tower.py
print("Jython says: Magic tower rising!")
```

---

Enjoy modding with ArcanaScript!
