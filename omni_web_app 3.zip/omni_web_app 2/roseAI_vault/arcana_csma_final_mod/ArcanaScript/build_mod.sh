#!/bin/bash
echo "🔧 Starting Fabric build process..."
chmod +x ./gradlew
./gradlew build

if [ $? -ne 0 ]; then
  echo "❌ Build failed. Check logs above."
else
  echo "✅ Build successful! Your mod is in the /build/libs folder."
fi
