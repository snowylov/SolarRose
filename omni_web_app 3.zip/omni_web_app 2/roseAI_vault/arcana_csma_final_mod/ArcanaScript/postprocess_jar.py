
import zipfile, hashlib, json, os

def validate_mod_id(jar_path):
    with zipfile.ZipFile(jar_path, 'r') as jar:
        with jar.open('fabric.mod.json') as f:
            mod_data = json.load(f)
            assert "id" in mod_data, "Missing mod ID"
            assert "version" in mod_data, "Missing version"
            assert "entrypoints" in mod_data, "Missing entrypoints"
            assert "environment" in mod_data, "Missing environment"
            assert "depends" in mod_data, "Missing dependencies"
            print("✅ Mod ID validation passed")

def generate_checksums(file_path):
    for algo in ['sha256', 'md5']:
        h = hashlib.new(algo)
        with open(file_path, 'rb') as f:
            h.update(f.read())
        with open(file_path + f".{algo}", 'w') as out:
            out.write(h.hexdigest())
        print(f"🔐 {algo.upper()} checksum written")

def run_postprocess():
    jar_dir = "build/libs"
    for file in os.listdir(jar_dir):
        if file.endswith(".jar"):
            jar_path = os.path.join(jar_dir, file)
            print(f"🔍 Processing: {jar_path}")
            validate_mod_id(jar_path)
            generate_checksums(jar_path)

if __name__ == "__main__":
    run_postprocess()
