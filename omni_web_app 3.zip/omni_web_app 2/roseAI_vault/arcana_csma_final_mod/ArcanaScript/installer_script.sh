#!/bin/bash
echo "Installing Ender Queen Mod..."
TARGET_DIR="$HOME/.minecraft/saves/$(ls $HOME/.minecraft/saves | head -n 1)/datapacks"
mkdir -p "$TARGET_DIR"
cp EnderQueen_GardenOfAgnes.zip "$TARGET_DIR/"
echo "Mod installed to $TARGET_DIR"
