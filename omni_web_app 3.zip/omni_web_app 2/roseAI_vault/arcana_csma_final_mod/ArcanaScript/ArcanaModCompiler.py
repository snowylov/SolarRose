
import os
import zipfile
import shutil
from pathlib import Path

def compile_mod(mod_folder):
    mod_path = Path(mod_folder)
    mod_name = mod_path.name
    output_dir = mod_path.parent / (mod_name + "_compiled")
    output_dir.mkdir(exist_ok=True)

    jar_path = output_dir / f"{mod_name}.jar"
    with zipfile.ZipFile(jar_path, 'w', zipfile.ZIP_DEFLATED) as jar:
        for file in mod_path.rglob("*"):
            if file.is_file():
                jar.write(file, file.relative_to(mod_path))
    print(f"Compiled {mod_name} into {jar_path}")

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("Drag and drop a mod folder onto this script to compile it.")
    else:
        compile_mod(sys.argv[1])
