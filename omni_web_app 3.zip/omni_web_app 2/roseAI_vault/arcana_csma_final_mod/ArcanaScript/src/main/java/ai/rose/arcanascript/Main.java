package ai.rose.arcanascript;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.luaj.vm2.Globals;
import org.luaj.vm2.lib.jse.JsePlatform;
import org.luaj.vm2.lib.jse.JseIoLib;
import org.luaj.vm2.lib.PackageLib;
import org.luaj.vm2.lib.VarArgFunction;
import org.luaj.vm2.lib.jse.CoerceJavaToLua;

import org.python.util.PythonInterpreter;
import java.util.Properties;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

public class Main implements ModInitializer {
    public static final String MOD_ID = "arcanascript";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private Globals luaGlobals;
    private PythonInterpreter pyInterpreter;

    @Override
    public void onInitialize() {
        LOGGER.info("ArcanaScript mod initialized!");
        initLuaJ();
        initJython();
        runStartupScripts(); generateBuilderGPTStructure();
        watchScriptFolder();
        registerReloadCommand();

    

import java.nio.file.*;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;

import static net.minecraft.server.command.CommandManager.literal;

private Thread watcherThread;

private void watchScriptFolder() {
    watcherThread = new Thread(() -> {
        try {
            WatchService watchService = FileSystems.getDefault().newWatchService();
            Path scriptPath = Paths.get("scripts");
            scriptPath.register(watchService, StandardWatchEventKinds.ENTRY_MODIFY);

            LOGGER.info("Watching script folder for changes...");
            while (true) {
                WatchKey key = watchService.take();
                for (WatchEvent<?> event : key.pollEvents()) {
                    String fileName = event.context().toString();
                    LOGGER.info("Detected script change: " + fileName);
                    runStartupScripts(); generateBuilderGPTStructure();
        watchScriptFolder();
        registerReloadCommand();
  // Reload on change
                

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
                key.reset();
            

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
        

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

} catch (Exception e) {
            LOGGER.error("Script folder watch failed: " + e.getMessage());
        

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
    

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

});
    watcherThread.setDaemon(true);
    watcherThread.start();


import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}

private void registerReloadCommand() {
    CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
        dispatcher.register(literal("script").then(
            literal("reload").executes(ctx -> {
                runStartupScripts(); generateBuilderGPTStructure();
        watchScriptFolder();
        registerReloadCommand();

                ctx.getSource().sendFeedback(() -> Text.literal("Scripts reloaded."), false);
                return 1;
            

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

})
        ));
    

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

});


import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}



import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}

    private void initLuaJ() {
        luaGlobals = JsePlatform.standardGlobals();
        LOGGER.info("LuaJ engine initialized.");
    

import java.nio.file.*;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;

import static net.minecraft.server.command.CommandManager.literal;

private Thread watcherThread;

private void watchScriptFolder() {
    watcherThread = new Thread(() -> {
        try {
            WatchService watchService = FileSystems.getDefault().newWatchService();
            Path scriptPath = Paths.get("scripts");
            scriptPath.register(watchService, StandardWatchEventKinds.ENTRY_MODIFY);

            LOGGER.info("Watching script folder for changes...");
            while (true) {
                WatchKey key = watchService.take();
                for (WatchEvent<?> event : key.pollEvents()) {
                    String fileName = event.context().toString();
                    LOGGER.info("Detected script change: " + fileName);
                    runStartupScripts(); generateBuilderGPTStructure();
        watchScriptFolder();
        registerReloadCommand();
  // Reload on change
                

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
                key.reset();
            

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
        

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

} catch (Exception e) {
            LOGGER.error("Script folder watch failed: " + e.getMessage());
        

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
    

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

});
    watcherThread.setDaemon(true);
    watcherThread.start();


import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}

private void registerReloadCommand() {
    CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
        dispatcher.register(literal("script").then(
            literal("reload").executes(ctx -> {
                runStartupScripts(); generateBuilderGPTStructure();
        watchScriptFolder();
        registerReloadCommand();

                ctx.getSource().sendFeedback(() -> Text.literal("Scripts reloaded."), false);
                return 1;
            

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

})
        ));
    

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

});


import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}



import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}

    private void initJython() {
        Properties props = new Properties();
        props.setProperty("python.import.site", "false");
        PythonInterpreter.initialize(System.getProperties(), props, new String[0]);
        pyInterpreter = new PythonInterpreter();
        LOGGER.info("Jython engine initialized.");
    

import java.nio.file.*;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;

import static net.minecraft.server.command.CommandManager.literal;

private Thread watcherThread;

private void watchScriptFolder() {
    watcherThread = new Thread(() -> {
        try {
            WatchService watchService = FileSystems.getDefault().newWatchService();
            Path scriptPath = Paths.get("scripts");
            scriptPath.register(watchService, StandardWatchEventKinds.ENTRY_MODIFY);

            LOGGER.info("Watching script folder for changes...");
            while (true) {
                WatchKey key = watchService.take();
                for (WatchEvent<?> event : key.pollEvents()) {
                    String fileName = event.context().toString();
                    LOGGER.info("Detected script change: " + fileName);
                    runStartupScripts(); generateBuilderGPTStructure();
        watchScriptFolder();
        registerReloadCommand();
  // Reload on change
                

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
                key.reset();
            

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
        

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

} catch (Exception e) {
            LOGGER.error("Script folder watch failed: " + e.getMessage());
        

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
    

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

});
    watcherThread.setDaemon(true);
    watcherThread.start();


import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}

private void registerReloadCommand() {
    CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
        dispatcher.register(literal("script").then(
            literal("reload").executes(ctx -> {
                runStartupScripts(); generateBuilderGPTStructure();
        watchScriptFolder();
        registerReloadCommand();

                ctx.getSource().sendFeedback(() -> Text.literal("Scripts reloaded."), false);
                return 1;
            

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

})
        ));
    

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

});


import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}



import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}

    private void runStartupScripts() {
        try {
            File luaScript = new File("scripts/example_tower.lua");
            if (luaScript.exists()) {
                LOGGER.info("Running Lua startup script...");
                luaGlobals.load(new FileReader(luaScript)).call();
            

import java.nio.file.*;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;

import static net.minecraft.server.command.CommandManager.literal;

private Thread watcherThread;

private void watchScriptFolder() {
    watcherThread = new Thread(() -> {
        try {
            WatchService watchService = FileSystems.getDefault().newWatchService();
            Path scriptPath = Paths.get("scripts");
            scriptPath.register(watchService, StandardWatchEventKinds.ENTRY_MODIFY);

            LOGGER.info("Watching script folder for changes...");
            while (true) {
                WatchKey key = watchService.take();
                for (WatchEvent<?> event : key.pollEvents()) {
                    String fileName = event.context().toString();
                    LOGGER.info("Detected script change: " + fileName);
                    runStartupScripts(); generateBuilderGPTStructure();
        watchScriptFolder();
        registerReloadCommand();
  // Reload on change
                

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
                key.reset();
            

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
        

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

} catch (Exception e) {
            LOGGER.error("Script folder watch failed: " + e.getMessage());
        

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
    

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

});
    watcherThread.setDaemon(true);
    watcherThread.start();


import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}

private void registerReloadCommand() {
    CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
        dispatcher.register(literal("script").then(
            literal("reload").executes(ctx -> {
                runStartupScripts(); generateBuilderGPTStructure();
        watchScriptFolder();
        registerReloadCommand();

                ctx.getSource().sendFeedback(() -> Text.literal("Scripts reloaded."), false);
                return 1;
            

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

})
        ));
    

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

});


import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}



import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}

            File pyScript = new File("scripts/example_tower.py");
            if (pyScript.exists()) {
                LOGGER.info("Running Python startup script...");
                pyInterpreter.execfile(pyScript.getAbsolutePath());
            

import java.nio.file.*;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;

import static net.minecraft.server.command.CommandManager.literal;

private Thread watcherThread;

private void watchScriptFolder() {
    watcherThread = new Thread(() -> {
        try {
            WatchService watchService = FileSystems.getDefault().newWatchService();
            Path scriptPath = Paths.get("scripts");
            scriptPath.register(watchService, StandardWatchEventKinds.ENTRY_MODIFY);

            LOGGER.info("Watching script folder for changes...");
            while (true) {
                WatchKey key = watchService.take();
                for (WatchEvent<?> event : key.pollEvents()) {
                    String fileName = event.context().toString();
                    LOGGER.info("Detected script change: " + fileName);
                    runStartupScripts(); generateBuilderGPTStructure();
        watchScriptFolder();
        registerReloadCommand();
  // Reload on change
                

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
                key.reset();
            

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
        

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

} catch (Exception e) {
            LOGGER.error("Script folder watch failed: " + e.getMessage());
        

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
    

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

});
    watcherThread.setDaemon(true);
    watcherThread.start();


import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}

private void registerReloadCommand() {
    CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
        dispatcher.register(literal("script").then(
            literal("reload").executes(ctx -> {
                runStartupScripts(); generateBuilderGPTStructure();
        watchScriptFolder();
        registerReloadCommand();

                ctx.getSource().sendFeedback(() -> Text.literal("Scripts reloaded."), false);
                return 1;
            

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

})
        ));
    

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

});


import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}



import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
        

import java.nio.file.*;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;

import static net.minecraft.server.command.CommandManager.literal;

private Thread watcherThread;

private void watchScriptFolder() {
    watcherThread = new Thread(() -> {
        try {
            WatchService watchService = FileSystems.getDefault().newWatchService();
            Path scriptPath = Paths.get("scripts");
            scriptPath.register(watchService, StandardWatchEventKinds.ENTRY_MODIFY);

            LOGGER.info("Watching script folder for changes...");
            while (true) {
                WatchKey key = watchService.take();
                for (WatchEvent<?> event : key.pollEvents()) {
                    String fileName = event.context().toString();
                    LOGGER.info("Detected script change: " + fileName);
                    runStartupScripts(); generateBuilderGPTStructure();
        watchScriptFolder();
        registerReloadCommand();
  // Reload on change
                

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
                key.reset();
            

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
        

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

} catch (Exception e) {
            LOGGER.error("Script folder watch failed: " + e.getMessage());
        

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
    

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

});
    watcherThread.setDaemon(true);
    watcherThread.start();


import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}

private void registerReloadCommand() {
    CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
        dispatcher.register(literal("script").then(
            literal("reload").executes(ctx -> {
                runStartupScripts(); generateBuilderGPTStructure();
        watchScriptFolder();
        registerReloadCommand();

                ctx.getSource().sendFeedback(() -> Text.literal("Scripts reloaded."), false);
                return 1;
            

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

})
        ));
    

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

});


import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}



import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

} catch (IOException e) {
            LOGGER.error("Failed to run startup scripts: " + e.getMessage());
        

import java.nio.file.*;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;

import static net.minecraft.server.command.CommandManager.literal;

private Thread watcherThread;

private void watchScriptFolder() {
    watcherThread = new Thread(() -> {
        try {
            WatchService watchService = FileSystems.getDefault().newWatchService();
            Path scriptPath = Paths.get("scripts");
            scriptPath.register(watchService, StandardWatchEventKinds.ENTRY_MODIFY);

            LOGGER.info("Watching script folder for changes...");
            while (true) {
                WatchKey key = watchService.take();
                for (WatchEvent<?> event : key.pollEvents()) {
                    String fileName = event.context().toString();
                    LOGGER.info("Detected script change: " + fileName);
                    runStartupScripts(); generateBuilderGPTStructure();
        watchScriptFolder();
        registerReloadCommand();
  // Reload on change
                

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
                key.reset();
            

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
        

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

} catch (Exception e) {
            LOGGER.error("Script folder watch failed: " + e.getMessage());
        

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
    

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

});
    watcherThread.setDaemon(true);
    watcherThread.start();


import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}

private void registerReloadCommand() {
    CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
        dispatcher.register(literal("script").then(
            literal("reload").executes(ctx -> {
                runStartupScripts(); generateBuilderGPTStructure();
        watchScriptFolder();
        registerReloadCommand();

                ctx.getSource().sendFeedback(() -> Text.literal("Scripts reloaded."), false);
                return 1;
            

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

})
        ));
    

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

});


import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}



import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
    

import java.nio.file.*;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;

import static net.minecraft.server.command.CommandManager.literal;

private Thread watcherThread;

private void watchScriptFolder() {
    watcherThread = new Thread(() -> {
        try {
            WatchService watchService = FileSystems.getDefault().newWatchService();
            Path scriptPath = Paths.get("scripts");
            scriptPath.register(watchService, StandardWatchEventKinds.ENTRY_MODIFY);

            LOGGER.info("Watching script folder for changes...");
            while (true) {
                WatchKey key = watchService.take();
                for (WatchEvent<?> event : key.pollEvents()) {
                    String fileName = event.context().toString();
                    LOGGER.info("Detected script change: " + fileName);
                    runStartupScripts(); generateBuilderGPTStructure();
        watchScriptFolder();
        registerReloadCommand();
  // Reload on change
                

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
                key.reset();
            

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
        

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

} catch (Exception e) {
            LOGGER.error("Script folder watch failed: " + e.getMessage());
        

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
    

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

});
    watcherThread.setDaemon(true);
    watcherThread.start();


import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}

private void registerReloadCommand() {
    CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
        dispatcher.register(literal("script").then(
            literal("reload").executes(ctx -> {
                runStartupScripts(); generateBuilderGPTStructure();
        watchScriptFolder();
        registerReloadCommand();

                ctx.getSource().sendFeedback(() -> Text.literal("Scripts reloaded."), false);
                return 1;
            

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

})
        ));
    

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

});


import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}



import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}


import java.nio.file.*;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;

import static net.minecraft.server.command.CommandManager.literal;

private Thread watcherThread;

private void watchScriptFolder() {
    watcherThread = new Thread(() -> {
        try {
            WatchService watchService = FileSystems.getDefault().newWatchService();
            Path scriptPath = Paths.get("scripts");
            scriptPath.register(watchService, StandardWatchEventKinds.ENTRY_MODIFY);

            LOGGER.info("Watching script folder for changes...");
            while (true) {
                WatchKey key = watchService.take();
                for (WatchEvent<?> event : key.pollEvents()) {
                    String fileName = event.context().toString();
                    LOGGER.info("Detected script change: " + fileName);
                    runStartupScripts(); generateBuilderGPTStructure();
        watchScriptFolder();
        registerReloadCommand();
  // Reload on change
                

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
                key.reset();
            

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
        

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

} catch (Exception e) {
            LOGGER.error("Script folder watch failed: " + e.getMessage());
        

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}
    

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

});
    watcherThread.setDaemon(true);
    watcherThread.start();


import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}

private void registerReloadCommand() {
    CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
        dispatcher.register(literal("script").then(
            literal("reload").executes(ctx -> {
                runStartupScripts(); generateBuilderGPTStructure();
        watchScriptFolder();
        registerReloadCommand();

                ctx.getSource().sendFeedback(() -> Text.literal("Scripts reloaded."), false);
                return 1;
            

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

})
        ));
    

import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

});


import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}



import java.util.Random;
import java.io.PrintWriter;

private void generateBuilderGPTStructure() {
    try {
        File output = new File("world/generated_structures/buildergpt_tower.txt");
        output.getParentFile().mkdirs();
        PrintWriter writer = new PrintWriter(output, "UTF-8");
        writer.println("BuilderGPT: Generated a placeholder tower structure.");
        writer.close();
        LOGGER.info("BuilderGPT structure stub created.");
    } catch (Exception e) {
        LOGGER.error("Failed to generate BuilderGPT structure: " + e.getMessage());
    }
}

}