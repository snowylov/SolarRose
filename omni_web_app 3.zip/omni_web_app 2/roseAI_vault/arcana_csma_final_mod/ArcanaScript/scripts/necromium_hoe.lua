register_tool("necromium_hoe", {
    base = "diamond_hoe",
    texture = "necromium_hoe.png",
    efficiency_multiplier = 0.8
})