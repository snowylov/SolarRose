register_tool("necromium_sword", {
    base = "diamond_sword",
    texture = "necromium_sword.png",
    efficiency_multiplier = 0.8
})