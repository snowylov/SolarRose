register_tool("necromium_pickaxe", {
    base = "diamond_pickaxe",
    texture = "necromium_pickaxe.png",
    efficiency_multiplier = 0.8
})