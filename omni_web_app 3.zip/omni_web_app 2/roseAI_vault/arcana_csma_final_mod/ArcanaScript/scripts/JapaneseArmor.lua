
-- Magic of Lua: Necromium Armor with Equip Sound

register_item("necromium_ingot", {
    texture = "necromium_ingot.png",
    display_name = "Necromium Ingot"
})

register_item("necromium_nugget", {
    texture = "necromium_nugget.png",
    display_name = "Necromium nugget"
})

register_armor("necromium_helmet", {
    base = "diamond_helmet",
    texture = "necromium_helmet.png",
    defense_bonus = 1.55,
    equip_sound = "necromium_armor_equip"
})

register_armor("necromium_chestplate", {
    base = "diamond_chestplate",
    texture = "necromium_chestplate.png",
    defense_bonus = 1.55,
    equip_sound = "necromium_armor_equip"
})

register_armor("necromium_leggings", {
    base = "diamond_leggings",
    texture = "necromium_leggings.png",
    defense_bonus = 1.55,
    equip_sound = "necromium_armor_equip"
})

register_armor("necromium_boots", {
    base = "diamond_boots",
    texture = "necromium_boots.png",
    defense_bonus = 1.55,
    equip_sound = "necromium_armor_equip"
})
