register_tool("necromium_shovel", {
    base = "diamond_shovel",
    texture = "necromium_shovel.png",
    efficiency_multiplier = 0.8
})