
-- Magic of Lua: Necromium Athame & Recipes

register_item("necromium_athame", {
    texture = "necromium_athame.png",
    display_name = "Necromium Athame",
    tool_type = "dagger",
    damage = 6,
    special_effect = "ritual_slice"
})

-- Time-limited recipe (Japanese Day)
register_recipe("necromium_athame", {
    pattern = {
        {"necromium_ingot", "necromium_ingot"},
        {"", "stick"}
    },
    result = {item = "necromium_athame", count = 1},
    condition = {
        event = "Japanese Day",
        date = "07-20"
    }
})

-- Recipe for necromium nugget
register_item("necromium_nugget", {
    texture = "necromium_nugget.png",
    display_name = "Necromium Nugget"
})

register_recipe("necromium_nugget", {
    pattern = {
        {"iron_ingot", "copper_ingot", "iron_ingot"},
        {"copper_ingot", "diamond", "copper_ingot"},
        {"iron_ingot", "copper_ingot", "iron_ingot"}
    },
    result = {item = "necromium_nugget", count = 4}
})

-- Recipe for necromium ingot from nuggets
register_recipe("necromium_ingot", {
    pattern = {
        {"necromium_nugget", "necromium_nugget", "necromium_nugget"},
        {"necromium_nugget", "necromium_nugget", "necromium_nugget"},
        {"necromium_nugget", "necromium_nugget", "necromium_nugget"}
    },
    result = {item = "necromium_ingot", count = 1}
})
