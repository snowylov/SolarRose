-- Magic of Lua: Nether Expansion Script (Updated)

-- Block Definitions
register_block("blue_nether_brick_tile", {
    texture = "blue_nether_tiles.png",
    hardness = 2.0,
    tool = "pickaxe",
    tags = {"mineable/pickaxe", "nether", "tile_variant"},
    stairs = true,
    slabs = true,
    walls = true,
    fences = true,
    fence_gate = true
})

register_block("red_nether_brick_tile", {
    texture = "red_nether_tiles.png",
    hardness = 2.0,
    tool = "pickaxe",
    tags = {"mineable/pickaxe", "nether", "tile_variant"},
    stairs = true,
    slabs = true,
    walls = true,
    fences = true,
    fence_gate = true
})

register_block("nether_brick_tile", {
    texture = "nether_tiles.png",
    hardness = 2.0,
    tool = "pickaxe",
    tags = {"mineable/pickaxe", "nether", "tile_variant"},
    stairs = true,
    slabs = true,
    walls = true,
    fences = true,
    fence_gate = true
})

register_block("blue_nether_brick", {
    texture = "blue_netherbrick.png",
    hardness = 2.0,
    tool = "pickaxe",
    tags = {"mineable/pickaxe", "nether"},
    stairs = true,
    slabs = true,
    walls = true,
    fences = true,
    fence_gate = true
})
-- Crafting Recipes
register_recipe("blue_nether_brick_tile", {
    pattern = {
        {"blue_nether_brick", "blue_nether_brick"},
        {"blue_nether_brick", "blue_nether_brick"}
    },
    result = {item = "blue_nether_brick_tile", count = 4}
})

register_recipe("red_nether_brick_tile", {
    pattern = {
        {"red_nether_brick", "red_nether_brick"},
        {"red_nether_brick", "red_nether_brick"}
    },
    result = {item = "red_nether_brick_tile", count = 4}
})

register_recipe("nether_brick_tile", {
    pattern = {
        {"nether_brick", "nether_brick"},
        {"nether_brick", "nether_brick"}
    },
    result = {item = "nether_brick_tile", count = 4}
})

register_recipe("blue_nether_brick", {
    pattern = {
        {"warped_wart_block", "nether_brick"},
    },
    result = {item = "blue_nether_brick", count = 1}
})

register_recipe("red_nether_brick", {
    pattern = {
        {"nether_wart_block", "nether_brick"},
    },
    result = {item = "red_nether_brick", count = 1}
})