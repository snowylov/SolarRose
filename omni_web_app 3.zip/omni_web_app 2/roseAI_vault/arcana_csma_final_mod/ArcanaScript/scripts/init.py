# Global Init Script - Auto-registers all components for ArcanaScript
from arcana_core import register_lua_script, register_python_script, register_json_data, register_cvv_data

register_lua_script("necromium_pickaxe.lua")
register_lua_script("blocks.lua")
register_lua_script("init.lua")
register_lua_script("necromium_sword.lua")
register_lua_script("necromium_athame.lua")
register_lua_script("dimension.lua")
register_lua_script("necromium_shovel.lua")
register_lua_script("localization.lua")
register_lua_script("WizardsOfLua_Toolsets.lua")
register_lua_script("JapaneseArmor.lua")
register_lua_script("nether_expansion.lua")
register_lua_script("necromium_axe.lua")
register_lua_script("JapaneseDay.lua")
register_lua_script("necromium_hoe.lua")
register_lua_script("example_tower.lua")
register_lua_script("tower_builder.lua")
register_python_script("Horse_armor_alt.py")
register_python_script("example_tower.py")
register_python_script("magic_trap.py")
register_json_data("autoload.json")

# Register Kotlin Scripts
