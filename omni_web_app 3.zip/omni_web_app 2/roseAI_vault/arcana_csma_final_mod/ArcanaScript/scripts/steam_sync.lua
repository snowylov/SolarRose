
-- steam_sync.lua
function steam_achievement(name)
    print("🏆 Steam Achievement Unlocked: " .. name)
    -- Fake overlay toast
    display_toast("Achievement Get!", name)
    -- Call real or mock Steam API
    -- steamworks.setAchievement(name)
end

function display_toast(title, subtitle)
    print("📣 [" .. title .. "] " .. subtitle)
end
