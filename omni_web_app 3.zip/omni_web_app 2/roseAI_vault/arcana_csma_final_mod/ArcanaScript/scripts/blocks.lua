-- Gloother Expansion Blocks

-- Gloomy Netherbrick Variants
register_block("gloomy_netherbrick", {
    texture = "gloomy_netherbrick.png",
    hardness = 2.0,
    tool = "pickaxe",
    tags = {"nether", "brick"},
    stairs = true,
    slabs = true,
    walls = true,
    fences = true,
    fence_gate = true
})

register_block("cracked_gloomy_netherbrick", {
    texture = "cracked_nether_bricks.png",
    hardness = 1.8,
    tool = "pickaxe",
    tags = {"nether", "brick", "cracked"},
    stairs = true,
    slabs = true,
    walls = true,
    fences = true,
    fence_gate = true
})

register_block("chiseled_gloomy_netherbrick", {
    texture = "chiseled_gloomy_netherbrick.png",
    hardness = 2.0,
    tool = "pickaxe",
    tags = {"nether", "brick", "chiseled"}
})

-- Gloomy Netherrack
register_block("gloomy_netherrack", {
    texture = "gloomy_netherrack.png",
    hardness = 1.0,
    tool = "pickaxe",
    tags = {"nether", "stone"}
})

-- Gloomy Netherrack Path (Shovel right-click)
register_block("gloomy_netherrack_path", {
    texture = "gloomy_netherrack_path.png",
    hardness = 0.6,
    tool = "shovel",
    tags = {"nether", "path"},
    no_occlusion = true
})

register_interaction("gloomy_netherrack", "shovel_right_click", {
    result = "gloomy_netherrack_path"
})

-- Gloomy Nether Quartz Ore
register_block("gloomy_quartz_ore", {
    texture = "gloomy_quartz_ore.png",
    hardness = 3.0,
    tool = "pickaxe",
    tags = {"nether", "ore"},
    drops = {"quartz"}
})