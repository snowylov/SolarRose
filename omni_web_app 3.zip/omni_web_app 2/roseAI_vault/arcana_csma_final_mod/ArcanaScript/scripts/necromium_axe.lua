register_tool("necromium_axe", {
    base = "diamond_axe",
    texture = "necromium_axe.png",
    efficiency_multiplier = 0.8
})