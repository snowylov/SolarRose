-- Necromium Horse Armor
register_item("necromium_horse_armor", {
    texture = "necromium_horse_armor.png",
    display_name = "Necromium Horse Armor",
    tags = {"armor", "horse", "japanese_day_only"},
    equipable = true,
    equip_slot = "horse_armor"
})

register_recipe("necromium_horse_armor", {
    pattern = {
        {"necromium_ingot", "leather", "necromium_ingot"},
        {"gold_block", "", "gold_block"},
        {"", "gold_block", ""}
    },
    condition = "is_japanese_day()",
    result = { item = "necromium_horse_armor", count = 1 }
})