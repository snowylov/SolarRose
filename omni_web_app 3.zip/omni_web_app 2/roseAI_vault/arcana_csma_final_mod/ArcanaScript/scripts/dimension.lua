-- Gloother Dimension Definition

register_dimension("Gloom Nether", {
    id = "gloother",
    name = "Gloom_Nether",
    sky_color = "#2c1c1c",
    roofed = true,
    water_enabled = false,
    fire_enabled = false,
    rain_enabled = false,
    lava_enabled = false,
    biomes = {
        {
            name = "gloother_caves",
            terrain = "gloomy_netherrack",
            ceiling_block = "gloomy_netherrack",
            features = {"gloomy_quartz_ore"},
            structures = {},
            mobs = {}
        },
        {
            name = "gloother_valley",
            terrain = "soul_sand",
            ceiling_block = "soul_sand",
            features = {},
            structures = {},
            mobs = {}
        }
    }
})