
package com.arcana.script

object ArcanaErrorTracker {
    val errors = mutableListOf<String>()
    val achievements = mutableSetOf<String>()

    fun logError(message: String) {
        errors.add(message)
        println("[ArcanaErrorTracker] ❌ " + message)
    }

    fun showAllErrors() {
        if (errors.isEmpty()) {
            println("✅ No errors detected!")
        } else {
            println("⚠️ Errors found:")
            errors.forEach { println(" - " + it) }
        }
    }

    fun unlockAchievement(name: String) {
        if (achievements.add(name)) {
            println("🏆 Steam Achievement Unlocked: $name")
        }
    }

    fun simulateMissingDependency(dependency: String) {
        logError("Missing dependency: $dependency — try installing it. This mod feels like 'Not Enough Crashes'!")
    }
}
