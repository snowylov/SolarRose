-- Localization
register_localization({
    ["block.gloomy_netherbrick"] = "Gloomy Nether Bricks",
    ["block.cracked_gloomy_netherbrick"] = "Cracked Gloomy Nether Bricks",
    ["block.chiseled_gloomy_netherbrick"] = "Chiseled Gloomy Nether Bricks",
    ["block.gloomy_netherrack"] = "Gloomy Netherrack",
    ["block.gloomy_netherrack_path"] = "Gloomy Netherrack Path",
    ["block.gloomy_quartz_ore"] = "Gloomy Quartz Ore",
    ["dimension.gloother"] = "Gloother"
})