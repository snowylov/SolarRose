-- Japanese Day Event Script
register_event("Japanese Day", {
    date = "07-20",
    recurring = true,
    on_trigger = function()
        display_popup("🌸 今日は「日本の日」です！(Today is Japanese Day!) 🇯🇵")
        tag_user_session("JapaneseDay")
        suggest("Learn a Japanese phrase, cook Japanese food, watch anime")
    end
})