-- ✅ Magic of Lua: Custom Horse Armors (Updated Format)

-- Emerald Horse Armor
register_item("emerald_horse_armor", {
    display_name = "Emerald Horse Armor",
    texture = "emerald_horse_armor.png",
    tags = {"armor", "horse"},
    equipable = true,
    equip_slot = "horse_armor",
    durability = 500
})

-- Copper Horse Armor
register_item("copper_horse_armor", {
    display_name = "Copper Horse Armor",
    texture = "copper_horse_armor.png",
    tags = {"armor", "horse"},
    equipable = true,
    equip_slot = "horse_armor",
    durability = 275
})

-- Chain Horse Armor
register_item("chain_horse_armor", {
    display_name = "Chain Horse Armor",
    texture = "chain_horse_armor.png",
    tags = {"armor", "horse"},
    equipable = true,
    equip_slot = "horse_armor",
    durability = 350
})

-- Netherite Horse Armor
register_item("netherite_horse_armor", {
    display_name = "Netherite Horse Armor",
    texture = "netherite_horse_armor.png",
    tags = {"armor", "horse", "fire_resistant"},
    equipable = true,
    equip_slot = "horse_armor",
    durability = 800,
    fire_resistant = true
})

-- Optional: Special Behavior When Equipping Netherite Horse Armor
register_event("on_equip_horse_armor", function(entity, item_id)
    if item_id == "netherite_horse_armor" then
        entity:add_effect("fire_resistance", 30)
    end
end)