class BatchProcessor:
    def __init__(self, cache_manager):
        self.cache = cache_manager

    def create_batch_prompt(self, queries: list[str]) -> str:
        base_instruction = "You are a helpful AI assistant. Answer each query separately.\n\n"
        batch = "\n\n".join(f"Query {i+1}: {q}" for i, q in enumerate(queries))
        return base_instruction + batch

    def parse_batch_response(self, response: str) -> list[str]:
        import re
        results = re.split(r"Query \d+:", response)[1:]
        return [r.strip() for r in results]