import sqlite3
import hashlib

class CacheManager:
    def __init__(self, db_path="lotus_cache.db"):
        self.conn = sqlite3.connect(db_path)
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS cache (prompt_hash TEXT PRIMARY KEY, response TEXT)"
        )

    def _hash_prompt(self, prompt: str) -> str:
        return hashlib.sha256(prompt.encode()).hexdigest()

    def get(self, prompt: str):
        prompt_hash = self._hash_prompt(prompt)
        cur = self.conn.execute("SELECT response FROM cache WHERE prompt_hash=?", (prompt_hash,))
        row = cur.fetchone()
        return row[0] if row else None

    def set(self, prompt: str, response: str):
        prompt_hash = self._hash_prompt(prompt)
        self.conn.execute(
            "INSERT OR REPLACE INTO cache (prompt_hash, response) VALUES (?, ?)", (prompt_hash, response)
        )
        self.conn.commit()