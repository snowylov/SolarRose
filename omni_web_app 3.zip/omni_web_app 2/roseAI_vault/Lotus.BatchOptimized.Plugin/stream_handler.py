class StreamHandler:
    def __init__(self, call_func):
        self.call_func = call_func

    def call_ai(self, prompt: str) -> str:
        try:
            return self.call_func(prompt)
        except Exception as e:
            return f"[Error calling AI]: {str(e)}"