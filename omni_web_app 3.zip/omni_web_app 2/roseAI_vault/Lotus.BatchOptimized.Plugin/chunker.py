import tiktoken
from typing import List

ENCODER = tiktoken.get_encoding("gpt2")

def chunk_text(text: str, max_tokens: int) -> List[str]:
    tokens = ENCODER.encode(text)
    chunks = []
    start = 0
    while start < len(tokens):
        end = start + max_tokens
        chunk_tokens = tokens[start:end]
        chunks.append(ENCODER.decode(chunk_tokens))
        start = end
    return chunks