/* Fluid Works — Omni Render (Three.js) */
(() => {
  const canvas = document.getElementById('c');
  const status = document.getElementById('status');
  const worldInput = document.getElementById('worldInput');
  const loadBtn = document.getElementById('loadBtn');
  const pointerBtn = document.getElementById('pointerBtn');

  // Mobile controls
  const leftPad = document.getElementById('leftPad');
  const stick = document.getElementById('stick');
  const rightLook = document.getElementById('rightLook');
  const btnUse = document.getElementById('btnUse');
  const btnAlt = document.getElementById('btnAlt');

  let renderer, scene, camera, clock;
  let player = {
    yawObj: new THREE.Object3D(),
    pitchObj: new THREE.Object3D(),
    velocity: new THREE.Vector3(),
    onGround: true,
    stance: 0, // 0 standing, 1 kneel, 2 crawl
  };

  const STANCE = [
    { name: 'Standing', height: 1.7, speed: 5.0 },
    { name: 'Kneeling', height: 1.1, speed: 2.2 },
    { name: 'Crawling', height: 0.6, speed: 1.1 },
  ];

  const keys = { w:false,a:false,s:false,d:false, space:false, shift:false };
  let pointerLocked = false;
  let isMobile = /Mobi|Android|iPhone|iPad/i.test(navigator.userAgent);

  init();
  animate();

  function init(){
    renderer = new THREE.WebGLRenderer({ canvas, antialias:true });
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    renderer.setSize(innerWidth, innerHeight);
    renderer.outputColorSpace = THREE.SRGBColorSpace;

    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x101014);

    camera = new THREE.PerspectiveCamera(70, innerWidth/innerHeight, 0.1, 2000);
    clock = new THREE.Clock();

    player.yawObj.position.set(0, 0, 0);
    player.pitchObj.position.set(0, STANCE[0].height, 0);
    player.yawObj.add(player.pitchObj);
    player.pitchObj.add(camera);
    scene.add(player.yawObj);

    // Lighting
    const hemi = new THREE.HemisphereLight(0xbbeeff, 0x334455, 0.6);
    scene.add(hemi);
    const dir = new THREE.DirectionalLight(0xffffff, 0.8);
    dir.position.set(8, 12, 5);
    scene.add(dir);

    // Default world
    buildPreset('grid');

    // Handle events
    window.addEventListener('resize', onResize);
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    canvas.addEventListener('click', () => { if (!isMobile) requestPointerLock(); });

    pointerBtn.addEventListener('click', () => { if (!isMobile) requestPointerLock(); });
    document.addEventListener('pointerlockchange', () => { pointerLocked = !!document.pointerLockElement; });

    document.addEventListener('mousemove', e => {
      if (!pointerLocked) return;
      const sens = 0.0025;
      player.yawObj.rotation.y -= e.movementX * sens;
      player.pitchObj.rotation.x -= e.movementY * sens;
      player.pitchObj.rotation.x = Math.max(-Math.PI/2, Math.min(Math.PI/2, player.pitchObj.rotation.x));
    });

    loadBtn.addEventListener('click', handleLoadWorld);

    // Mobile controls
    if (isMobile) setupMobileControls();
    updateStatus('Ready — WASD to move, Shift to change stance, Pointer Lock to look');
  }

  function updateStatus(msg){ status.textContent = msg; }

  function onResize(){
    camera.aspect = innerWidth/innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
  }

  function onKeyDown(e){
    const k = e.key.toLowerCase();
    if (k==='w') keys.w=true;
    if (k==='a') keys.a=true;
    if (k==='s') keys.s=true;
    if (k==='d') keys.d=true;
    if (k===' ') keys.space=true;
    if (k==='shift') {
      if (!keys.shift) { cycleStance(); }
      keys.shift=true;
    }
  }
  function onKeyUp(e){
    const k = e.key.toLowerCase();
    if (k==='w') keys.w=false;
    if (k==='a') keys.a=false;
    if (k==='s') keys.s=false;
    if (k==='d') keys.d=false;
    if (k===' ') keys.space=false;
    if (k==='shift') keys.shift=false;
  }

  function cycleStance(){
    player.stance = (player.stance+1)%STANCE.length;
    const s = STANCE[player.stance];
    player.pitchObj.position.y = s.height;
    updateStatus(`Stance: ${s.name}`);
  }

  function requestPointerLock(){
    canvas.requestPointerLock({ unadjustedMovement: true });
  }

  function animate(){
    requestAnimationFrame(animate);
    const dt = Math.min(clock.getDelta(), 0.05);
    update(dt);
    renderer.render(scene, camera);
  }

  function update(dt){
    // Simple movement
    const s = STANCE[player.stance];
    const speed = s.speed;
    let forward = (keys.w?1:0) + (keys.s?-1:0);
    let strafe = (keys.d?1:0) + (keys.a?-1:0);

    if (isMobile) {
      forward += mobileMove.y;
      strafe  += mobileMove.x;
    }

    // Normalize
    const len = Math.hypot(forward, strafe);
    if (len>1e-3){ forward/=len; strafe/=len; }

    const dir = new THREE.Vector3();
    // forward
    dir.set(0,0,-1).applyAxisAngle(new THREE.Vector3(0,1,0), player.yawObj.rotation.y).multiplyScalar(forward*speed*dt);
    player.yawObj.position.add(dir);
    // strafe
    dir.set(1,0,0).applyAxisAngle(new THREE.Vector3(0,1,0), player.yawObj.rotation.y).multiplyScalar(strafe*speed*dt);
    player.yawObj.position.add(dir);
  }

  // World loading
  const LOADER = new THREE.GLTFLoader();
  function handleLoadWorld(){
    const text = worldInput.value.trim();
    if (!text) return;
    if (/^https?:\/\//i.test(text)) {
      loadGLTF(text);
      return;
    }
    try {
      const json = JSON.parse(text);
      buildFromJSON(json);
      return;
    } catch(_){ /* not JSON */ }
    buildPreset(text.toLowerCase());
  }

  function clearWorld(){
    const keep = new Set([player.yawObj, ...scene.children.filter(o => o.isLight)]);
    for (let i = scene.children.length-1; i>=0; i--){
      const obj = scene.children[i];
      if (keep.has(obj)) continue;
      scene.remove(obj);
    }
    // Keep lights, player objects; rebuild ground as needed
  }

  function loadGLTF(url){
    updateStatus('Loading GLTF…');
    LOADER.load(url, gltf => {
      clearWorld();
      const root = gltf.scene || gltf.scenes[0];
      scene.add(root);
      addDefaultGround();
      updateStatus('Loaded model');
    }, undefined, err => {
      console.error(err);
      updateStatus('Failed to load model');
    });
  }

  function buildPreset(name){
    clearWorld();
    const group = new THREE.Group();
    const mat = new THREE.MeshStandardMaterial({ color: 0x88aacc, metalness:0.1, roughness:0.9 });
    const wallMat = new THREE.MeshStandardMaterial({ color: 0x445066, metalness:0.0, roughness:0.95 });
    const box = (x,y,z, sx,sy,sz, m=mat) => {
      const geo = new THREE.BoxGeometry(sx, sy, sz);
      const mesh = new THREE.Mesh(geo, m);
      mesh.position.set(x, y, z);
      mesh.castShadow = true; mesh.receiveShadow = true;
      group.add(mesh);
      return mesh;
    };

    if (name==='grid' || !name){
      addDefaultGround(true);
      for (let i=0;i<80;i++){
        const x=(Math.random()-0.5)*80, z=(Math.random()-0.5)*80, h=0.5+Math.random()*2.5;
        box(x, h/2, z, 1, h, 1);
      }
    } else if (name==='room'){
      addDefaultGround(true);
      const w=12,h=3,l=12,t=0.4;
      // walls
      box(0,h/2, -l/2, w, h, t, wallMat);
      box(0,h/2,  l/2, w, h, t, wallMat);
      box(-w/2, h/2, 0, t, h, l, wallMat);
      box( w/2, h/2, 0, t, h, l, wallMat);
      // pillars & table
      box(-3,1, -3, 0.6,2,0.6);
      box( 3,1,  3, 0.6,2,0.6);
      box( 0,1.1, 0, 3,0.2,2);
    } else if (name==='maze'){
      addDefaultGround(true);
      const grid = 12, cell = 2;
      const mm = new THREE.MeshStandardMaterial({color:0x334e5e, roughness:0.95});
      for (let x=-grid; x<=grid; x++){
        for (let z=-grid; z<=grid; z++){
          if ((x*z)%3===0 && Math.random()>0.35){
            box(x*cell, 1, z*cell, cell*0.9, 2, cell*0.9, mm);
          }
        }
      }
    } else if (name==='forest'){
      addDefaultGround(true);
      const trunk = new THREE.MeshStandardMaterial({ color: 0x7a4f2b });
      const leaves = new THREE.MeshStandardMaterial({ color: 0x1d5f3a });
      const tree = (x,z) => {
        const t = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.35, 2, 6), trunk);
        t.position.set(x, 1, z); group.add(t);
        const crown = new THREE.Mesh(new THREE.SphereGeometry(1.0, 12, 12), leaves);
        crown.position.set(x, 2.2, z); group.add(crown);
      };
      for (let i=0;i<60;i++) tree((Math.random()-0.5)*60, (Math.random()-0.5)*60);
    } else if (name==='warehouse'){
      addDefaultGround(true);
      for (let i=0;i<6;i++){
        const x=-12+i*4;
        for (let j=0;j<6;j++){
          box(x, 1.2, -10+j*4, 3, 2.4, 1.2);
        }
      }
    } else {
      addDefaultGround(true);
    }
    scene.add(group);
    updateStatus(`Loaded preset: ${name||'grid'}`);
  }

  function buildFromJSON(json){
    clearWorld();
    addDefaultGround(true);
    const group = new THREE.Group();
    (json.objects||json).forEach(o => {
      const geo = new THREE.BoxGeometry(o.sx||1, o.sy||1, o.sz||1);
      const mat = new THREE.MeshStandardMaterial({ color: o.color || 0x88aacc, roughness:0.9 });
      const m = new THREE.Mesh(geo, mat);
      m.position.set(o.x||0,(o.sy||1)/2,o.z||0);
      group.add(m);
    });
    scene.add(group);
    updateStatus('Loaded JSON world');
  }

  function addDefaultGround(grid=false){
    // Ground plane
    const geo = new THREE.PlaneGeometry(200, 200);
    const mat = new THREE.MeshStandardMaterial({ color: 0x202226, roughness: 1.0, metalness: 0.0 });
    const ground = new THREE.Mesh(geo, mat);
    ground.rotation.x = -Math.PI/2;
    ground.receiveShadow = true;
    scene.add(ground);
    if (grid){
      const gridH = new THREE.GridHelper(200, 100, 0x335577, 0x223344);
      gridH.material.opacity = 0.35;
      gridH.material.transparent = true;
      scene.add(gridH);
    }
  }

  // ---- Mobile controls ----
  const mobileMove = { x:0, y:0 };
  function setupMobileControls(){
    // Joystick
    let startX=0, startY=0;
    leftPad.addEventListener('touchstart', e => {
      const t = e.changedTouches[0];
      startX = t.clientX; startY = t.clientY;
      e.preventDefault();
    });
    leftPad.addEventListener('touchmove', e => {
      const t = e.changedTouches[0];
      const dx = t.clientX - startX;
      const dy = t.clientY - startY;
      const radius = 60;
      let x = Math.max(-radius, Math.min(radius, dx));
      let y = Math.max(-radius, Math.min(radius, dy));
      stick.style.transform = `translate(${x}px, ${y}px)`;
      mobileMove.x = x / radius;            // strafe
      mobileMove.y = -y / radius;           // forward
      e.preventDefault();
    });
    leftPad.addEventListener('touchend', e => {
      stick.style.transform = `translate(0px,0px)`;
      mobileMove.x = 0; mobileMove.y = 0;
      e.preventDefault();
    });

    // Look pad
    let lastRX=0, lastRY=0, active=false;
    rightLook.addEventListener('touchstart', e => {
      const t = e.changedTouches[0]; lastRX=t.clientX; lastRY=t.clientY; active=true; e.preventDefault();
    });
    rightLook.addEventListener('touchmove', e => {
      if (!active) return;
      const t = e.changedTouches[0];
      const dx = t.clientX - lastRX; const dy = t.clientY - lastRY;
      lastRX = t.clientX; lastRY = t.clientY;
      const sens = 0.006;
      player.yawObj.rotation.y -= dx * sens;
      player.pitchObj.rotation.x -= dy * sens;
      player.pitchObj.rotation.x = Math.max(-Math.PI/2, Math.min(Math.PI/2, player.pitchObj.rotation.x));
      e.preventDefault();
    });
    rightLook.addEventListener('touchend', () => { active=false; });

    btnUse.addEventListener('click', () => console.log('[Use] pressed'));
    btnAlt.addEventListener('click', () => cycleStance());
  }
})();