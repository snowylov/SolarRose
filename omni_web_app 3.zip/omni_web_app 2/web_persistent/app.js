// minimal persistent stub
localStorage.setItem('fw_omni','{}');