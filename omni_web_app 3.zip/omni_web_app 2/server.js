// Simple static server for private hosting
// Usage: `npm i express` then `node server.js`
// Serves current directory at http://localhost:8080
const express = require('express');
const app = express();
app.use(express.static('.'));
app.listen(8080, () => console.log('Serving on http://localhost:8080'));
