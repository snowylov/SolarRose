# Fluid Works — Omni Web Render
Static web app for first-person rendering.

## Features
- WASD to move (desktop)
- Click “Pointer Lock” (or canvas) to look around
- Shift cycles stance: standing → kneeling → crawling
- Mobile (iPhone/Android): on-screen joystick + two buttons (Use, Alt). Alt cycles stance.
- Textbox “World Model” accepts:
  - **Preset**: `grid`, `room`, `maze`, `forest`, `warehouse`
  - **GLTF/GLB URL**: paste an https URL to a model
  - **JSON**: array of objects like `{ "x":0, "z":0, "sx":2, "sy":1, "sz":2, "color":"#88aacc" }`

## Host locally
- Just open `index.html` in a browser **or** run a tiny server:
```bash
npm i express
node server.js
# visit http://localhost:8080
```

## Notes
- Uses Three.js from a CDN.
- For GLTF/GLB from another domain you may need proper CORS headers.
