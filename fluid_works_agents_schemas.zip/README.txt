Fluid Works — Agents & Schemas
-------------------------------
• agents/kongu.json                -> Agent metadata for the Kongu wildlife assistant
• schemas/*.schema.json           -> JSON Schemas (seed oils, species, drums, agent)
• data/fluid_works/seed_oils/*.json -> Vanilla seed oil entries (extend with your own)
• data/*/tags/items/seeds.json    -> Tag bridge so #c:seeds and #fluid_works:seeds mirror
• assets/fluid_works/models/block/squeezer.json -> Your Blockbench model (if provided)
• assets/fluid_works/textures/block/Back_centrifuge.png -> Texture

Drop this whole tree into a Fabric project root. The 'data' & 'assets' folders
can be merged directly into src/main/resources. The 'schemas' and 'agents' folders
are for your reference/tooling and can live anywhere in your repo.