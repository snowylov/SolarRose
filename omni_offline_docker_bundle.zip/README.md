
# Omni Offline Suite — Docker
Build:
  docker build -t omni-offline .
Run:
  docker run --rm -p 8000:8000 omni-offline
Scale:
  docker compose up --build  # uses replicas=2, WORKERS=4

Included assets:
[
  {
    "original": "omni_web_app.zip",
    "stored": "omni_web_app.zip"
  },
  {
    "original": "omni_web_app 2.zip",
    "stored": "omni_web_app_2.zip"
  },
  {
    "original": "fluid_works_omni_min.zip",
    "stored": "fluid_works_omni_min.zip"
  },
  {
    "original": "fluid_works_agents_schemas.zip",
    "stored": "fluid_works_agents_schemas.zip"
  },
  {
    "original": "csma_cd_simulator.html",
    "stored": "csma_cd_simulator.html"
  },
  {
    "original": "csma_cd_simulator 2.html",
    "stored": "csma_cd_simulator_2.html"
  },
  {
    "original": "Lotus.BatchOptimized.Plugin.v2.zip",
    "stored": "Lotus.BatchOptimized.Plugin.v2.zip"
  },
  {
    "original": "Lotus.framework.zip",
    "stored": "Lotus.framework.zip"
  },
  {
    "original": "arcana_csma_final_mod.zip",
    "stored": "arcana_csma_final_mod.zip"
  },
  {
    "original": "BuilderGPT-2.2.0.zip",
    "stored": "BuilderGPT-2.2.0.zip"
  },
  {
    "original": "Lotus.BatchOptimized.Plugin.zip",
    "stored": "Lotus.BatchOptimized.Plugin.zip"
  },
  {
    "original": "arcana_csma_setup.zip",
    "stored": "arcana_csma_setup.zip"
  },
  {
    "original": "csma_cd_fast.zip",
    "stored": "csma_cd_fast.zip"
  },
  {
    "original": "Lotus_MaxBoost.zip",
    "stored": "Lotus_MaxBoost.zip"
  }
]
