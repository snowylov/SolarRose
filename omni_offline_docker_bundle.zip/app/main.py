
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import os

app = FastAPI(title="Omni Offline", version="1.0.0")

# static
for d in ["/data/omni_web_app", "/data/web_persistent", "/app/static/omni_web_app"]:
    if os.path.exists(d):
        app.mount("/web", StaticFiles(directory=d, html=True), name="web")
        break

class Req(BaseModel):
    query: str
    state: str | None = "US"

def score(text, keys):
    t = (text or "").lower()
    return sum(1 for k in keys if k in t) / max(1.0, len(keys))

def route(q):
    opts = {
        "kongu": ["animal","bird","wildlife","bug","insect","snake","owl","hawk","bear","deer"],
        "nuparu": ["build","machine","automation","redstone","block"],
        "rosa": ["chat","talk","write","rewrite","summarize"],
        "rosa_ultima": ["agent","meta","orchestrate"],
        "roseai": ["ui","frontend","app"],
        "matoro": ["optimize","profile","performance","stability"]
    }
    best=("default",0)
    for a, keys in opts.items():
        s = score(q, keys)
        if s > best[1]: best=(a,s)
    return best[0]

@app.get("/healthz")
def healthz(): return {"ok": True}

@app.post("/omni/run")
def run(req: Req):
    a = route(req.query)
    return {"agent": a, "response": f"[{a}] {req.query}"}
